Lab 1A
Rishabh Aggarwal - 204461652
Luke Chui - 704637625

Please find answers to relevant questions in the other files in this folder
